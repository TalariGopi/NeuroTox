library(openxlsx)
args <- commandArgs(TRUE)
df <- as.character(args[1])
print(df)
#df <- "C:\\Users\\Sachin\\Downloads\\test.csv"
#df <- gsub("\\","/",df)
#df <- "C:/Users/Sachin/Downloads/test.csv"
nam <- gsub("@"," ",df)
df_nam <- read.csv(nam)
df_nam <- df_nam[2:nrow(df_nam),]
write.table(df_nam,"./Files/Results_M/PaDel/data.smi",row.names=FALSE, quote = FALSE,col.names = FALSE)
write.table(df_nam,"./Files/Results_M/PaDel_M/data.csv",row.names=FALSE, quote = FALSE)
            