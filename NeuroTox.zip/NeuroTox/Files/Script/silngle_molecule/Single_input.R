library(caret)
library(Boruta)
fit.rf<-readRDS(".\\Files\\Script\\silngle_molecule\\fit.rf.RDS")
useroutput<-read.csv(".\\Files\\Results\\Descriptor\\descriptor.csv")
usertestfile<-useroutput[,-1]
userpred<- predict(fit.rf,newdata=usertestfile)
xx<- as.character(userpred)
yy <- ifelse(xx=="NT", paste("NeuroToxic !!!"),paste("Safe !!!"))
print(yy)

